import Link from "next/link";
import {
  CircleDollarSign,
  LineChart,
  TrendingUp,
  Brain,
  Layers,
  BarChart2,
  Activity,
  Award,
  Bot,
  Shield,
  Zap,
  ArrowRight,
  Check,
  ChevronRight,
  BookOpen,
  Briefcase,
  BarChart3
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Home() {
  return (
    <div className="space-y-20">
      {/* Hero Section */}
      <section className="py-12 md:py-20 text-center space-y-6">
        <div className="inline-block p-1 px-3 mb-3 text-sm font-medium bg-primary/10 text-primary rounded-full">
          The Future of Financial Technology
        </div>
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight max-w-4xl mx-auto">
          The All-in-One <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-indigo-600">AI-Powered</span> Financial Platform
        </h1>
        <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
          Advanced stock predictions, no-code trading bots, and intelligent portfolio optimization in one unified platform
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center pt-6">
          <Button asChild size="lg" className="gap-2">
            <Link href="/dashboard">
              <LineChart className="h-5 w-5" />
              Get Started
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg" className="gap-2">
            <Link href="/pricing">
              <CircleDollarSign className="h-5 w-5" />
              View Pricing
            </Link>
          </Button>
        </div>

        {/* Stats */}
        <div className="pt-10 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
          <div>
            <div className="text-3xl md:text-4xl font-bold text-primary">75%+</div>
            <p className="text-sm text-muted-foreground">Prediction Accuracy</p>
          </div>
          <div>
            <div className="text-3xl md:text-4xl font-bold text-primary">50K+</div>
            <p className="text-sm text-muted-foreground">Active Users</p>
          </div>
          <div>
            <div className="text-3xl md:text-4xl font-bold text-primary">$2.5B+</div>
            <p className="text-sm text-muted-foreground">Assets Analyzed</p>
          </div>
          <div>
            <div className="text-3xl md:text-4xl font-bold text-primary">24/7</div>
            <p className="text-sm text-muted-foreground">Market Monitoring</p>
          </div>
        </div>
      </section>

      {/* Main Features Section */}
      <section className="space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-3xl md:text-4xl font-bold">Three Powerful Modules, One Platform</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Everything you need to analyze markets, automate trading, and optimize your portfolio
          </p>
        </div>

        <div className="grid gap-10 lg:grid-cols-3">
          <Card className="relative overflow-hidden border-blue-200 dark:border-blue-900 bg-gradient-to-br from-blue-50 to-white dark:from-slate-900 dark:to-slate-900">
            <div className="absolute top-0 right-0 -mt-4 -mr-4 h-24 w-24 rounded-full bg-blue-500/25 blur-xl" />
            <CardHeader className="pb-2">
              <div className="bg-blue-100 dark:bg-blue-900/50 w-12 h-12 rounded-lg flex items-center justify-center mb-2">
                <Brain className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <CardTitle className="text-xl font-bold">AI Stock Prediction</CardTitle>
              <CardDescription>
                Advanced machine learning models to forecast market movements
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 mb-6">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>Multi-timeframe price predictions (1-30 days)</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>Confidence intervals and volatility estimates</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>Real-time sentiment analysis from social & news</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>Explainable AI insights on prediction factors</span>
                </li>
              </ul>
              <Button asChild className="w-full gap-1 bg-blue-600 hover:bg-blue-700">
                <Link href="/stocks">
                  Explore Stock Predictions
                  <ChevronRight className="h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden border-purple-200 dark:border-purple-900 bg-gradient-to-br from-purple-50 to-white dark:from-slate-900 dark:to-slate-900">
            <div className="absolute top-0 right-0 -mt-4 -mr-4 h-24 w-24 rounded-full bg-purple-500/25 blur-xl" />
            <CardHeader className="pb-2">
              <div className="bg-purple-100 dark:bg-purple-900/50 w-12 h-12 rounded-lg flex items-center justify-center mb-2">
                <Bot className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <CardTitle className="text-xl font-bold">Trading Bot Builder</CardTitle>
              <CardDescription>
                Create, backtest, and deploy trading strategies without code
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 mb-6">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>Drag-and-drop strategy builder interface</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>AI-generated strategy suggestions</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>Comprehensive backtesting with performance metrics</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>Advanced risk management tools</span>
                </li>
              </ul>
              <Button asChild className="w-full gap-1 bg-purple-600 hover:bg-purple-700">
                <Link href="/trading-bot">
                  Create Trading Bots
                  <ChevronRight className="h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden border-green-200 dark:border-green-900 bg-gradient-to-br from-green-50 to-white dark:from-slate-900 dark:to-slate-900">
            <div className="absolute top-0 right-0 -mt-4 -mr-4 h-24 w-24 rounded-full bg-green-500/25 blur-xl" />
            <CardHeader className="pb-2">
              <div className="bg-green-100 dark:bg-green-900/50 w-12 h-12 rounded-lg flex items-center justify-center mb-2">
                <Briefcase className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <CardTitle className="text-xl font-bold">Portfolio Optimization</CardTitle>
              <CardDescription>
                Optimize asset allocation with advanced financial models
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 mb-6">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>Multiple optimization algorithms (MPT, Risk Parity)</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>AI-powered rebalancing recommendations</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>Risk profiling and goal-based investing</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span>Stress testing and performance analytics</span>
                </li>
              </ul>
              <Button asChild className="w-full gap-1 bg-green-600 hover:bg-green-700">
                <Link href="/portfolio">
                  Optimize Your Portfolio
                  <ChevronRight className="h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* AI Technology Section */}
      <section className="relative overflow-hidden py-10 border-y bg-muted/40">
        <div className="container relative z-10">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div className="space-y-5">
              <div className="inline-block p-1 px-3 text-sm font-medium bg-primary/10 text-primary rounded-full">
                Our Technology
              </div>
              <h2 className="text-3xl font-bold leading-tight">
                Powered by Advanced Machine Learning & Financial Engineering
              </h2>
              <p className="text-muted-foreground">
                Our platform combines state-of-the-art AI models with decades of financial expertise to deliver accurate predictions and intelligent optimization strategies.
              </p>
              <div className="space-y-3 pt-3">
                <div className="flex items-start">
                  <div className="bg-primary/10 p-1.5 rounded mt-0.5 mr-3">
                    <Zap className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">LSTM & Transformer Networks</h3>
                    <p className="text-sm text-muted-foreground">
                      Deep learning architectures optimized for time-series forecasting
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-primary/10 p-1.5 rounded mt-0.5 mr-3">
                    <Activity className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">Sentiment Analysis</h3>
                    <p className="text-sm text-muted-foreground">
                      NLP models that scan millions of social media posts and news articles
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-primary/10 p-1.5 rounded mt-0.5 mr-3">
                    <Shield className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium">Risk Management Algorithms</h3>
                    <p className="text-sm text-muted-foreground">
                      Sophisticated models to optimize risk-adjusted returns
                    </p>
                  </div>
                </div>
              </div>
              <div className="pt-3">
                <Button asChild variant="outline" className="gap-1">
                  <Link href="/about">
                    <BookOpen className="h-4 w-4" />
                    Learn More About Our Technology
                  </Link>
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="bg-white dark:bg-slate-800 shadow-lg rounded-lg p-5 transform hover:-translate-y-1 transition-transform">
                  <BarChart3 className="h-8 w-8 text-primary mb-3" />
                  <h3 className="font-medium text-lg">Stock Analysis</h3>
                  <p className="text-sm text-muted-foreground">
                    Technical and fundamental analysis with AI insights
                  </p>
                </div>
                <div className="bg-gradient-to-br from-primary/10 to-primary/5 shadow-lg rounded-lg p-5 transform hover:-translate-y-1 transition-transform">
                  <Bot className="h-8 w-8 text-primary mb-3" />
                  <h3 className="font-medium text-lg">Automated Trading</h3>
                  <p className="text-sm text-muted-foreground">
                    Rule-based and AI-enhanced trading strategies
                  </p>
                </div>
              </div>
              <div className="space-y-4 mt-10">
                <div className="bg-gradient-to-br from-blue-500/10 to-indigo-500/10 shadow-lg rounded-lg p-5 transform hover:-translate-y-1 transition-transform">
                  <Brain className="h-8 w-8 text-primary mb-3" />
                  <h3 className="font-medium text-lg">Prediction Models</h3>
                  <p className="text-sm text-muted-foreground">
                    Machine learning models trained on vast datasets
                  </p>
                </div>
                <div className="bg-white dark:bg-slate-800 shadow-lg rounded-lg p-5 transform hover:-translate-y-1 transition-transform">
                  <Briefcase className="h-8 w-8 text-primary mb-3" />
                  <h3 className="font-medium text-lg">Portfolio Tools</h3>
                  <p className="text-sm text-muted-foreground">
                    Advanced optimization and risk assessment
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Customer testimonials - Simplified Version */}
      <section className="py-10">
        <div className="text-center space-y-4 mb-10">
          <h2 className="text-3xl font-bold">Trusted by Investors Worldwide</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            See what our users say about Walford Capitals' AI-powered platform
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {[
            {
              quote: "The AI predictions have transformed my investment strategy. I'm seeing consistent returns that I never achieved with traditional analysis.",
              name: "Sarah J.",
              title: "Retail Investor"
            },
            {
              quote: "As a professional trader, the Trading Bot Builder saves me countless hours. I can quickly prototype and test strategies with just a few clicks.",
              name: "Michael T.",
              title: "Professional Trader"
            },
            {
              quote: "The portfolio optimization tools helped me reduce my portfolio's volatility while maintaining similar returns. Impressive technology.",
              name: "David K.",
              title: "Financial Advisor"
            }
          ].map((testimonial, i) => (
            <Card key={i} className="border-none bg-muted/60">
              <CardContent className="pt-6">
                <div className="text-primary mb-2">
                  {"★".repeat(5)}
                </div>
                <p className="italic mb-4">"{testimonial.quote}"</p>
                <div>
                  <p className="font-semibold">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.title}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="my-20">
        <div className="bg-gradient-to-br from-primary/20 via-primary/10 to-primary/5 py-16 px-6 rounded-lg border max-w-5xl mx-auto text-center space-y-6">
          <h2 className="text-3xl font-bold mb-4">Ready to transform your investment strategy?</h2>
          <p className="text-xl text-muted-foreground mb-6 max-w-2xl mx-auto">
            Join thousands of investors using Walford Capitals' AI-powered tools to make smarter investment decisions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild className="gap-1">
              <Link href="/auth?signup=true">
                Get Started for Free
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="gap-1">
              <Link href="/dashboard">
                View Demo
                <ChevronRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
