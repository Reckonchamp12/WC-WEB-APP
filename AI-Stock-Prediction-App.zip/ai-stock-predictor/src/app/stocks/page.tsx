"use client";

import { useState } from "react";
import {
  CircleDollarSign,
  LineChart,
  BarChart2,
  TrendingUp,
  TrendingDown,
  Clock,
  Calendar,
  Search
} from "lucide-react";
import { StockChart } from "@/components/charts/StockChart";
import { ModelExplainer } from "@/components/ai/ModelExplainer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// Mock data for a stock
const STOCK_DATA = {
  symbol: "AAPL",
  name: "Apple Inc.",
  price: 188.25,
  change: +4.32,
  changePercent: +2.35,
  prediction: {
    next5Days: "+2.3%",
    confidence: 84,
    direction: "up",
  },
  fundamentals: {
    marketCap: "2.94T",
    peRatio: "32.14",
    dividend: "0.92 (0.49%)",
    volume: "58.34M",
    avgVolume: "62.17M",
    high52w: "199.62",
    low52w: "124.17",
    eps: "6.14",
  },
  upcomingEvents: [
    { id: 1, name: "Q3 Earnings Release", date: "July 27, 2025", days: 18 },
    { id: 2, name: "Annual Shareholder Meeting", date: "Feb 28, 2026", days: 234 },
    { id: 3, name: "Product Launch Event", date: "Sept 12, 2025", days: 65 },
  ],
};

export default function StocksPage() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Stock Analysis</h1>
          <p className="text-muted-foreground">
            AI-powered stock predictions and analysis.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search for a stock..."
              className="pl-8 w-full md:w-[260px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button>Search</Button>
        </div>
      </div>

      {/* Stock Header with Current Price */}
      <div className="flex flex-col md:flex-row md:items-center gap-4 md:gap-8">
        <div className="flex items-center gap-3">
          <div className="bg-primary/10 p-3 rounded-full">
            <CircleDollarSign className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-2">
              {STOCK_DATA.symbol}
              <span className="text-lg font-normal text-muted-foreground">{STOCK_DATA.name}</span>
            </h2>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold">${STOCK_DATA.price}</span>
              <span className={`flex items-center text-sm ${
                STOCK_DATA.change > 0 ? "text-green-500" : "text-red-500"
              }`}>
                {STOCK_DATA.change > 0 ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
                {STOCK_DATA.change > 0 ? "+" : ""}{STOCK_DATA.change} ({STOCK_DATA.changePercent > 0 ? "+" : ""}{STOCK_DATA.changePercent}%)
              </span>
            </div>
          </div>
        </div>

        <div className="flex gap-4 ml-0 md:ml-auto">
          <div className="bg-primary/5 px-4 py-2 rounded-lg">
            <div className="text-sm text-muted-foreground">Prediction (5d)</div>
            <div className="flex items-center">
              <span className={`text-lg font-bold ${
                STOCK_DATA.prediction.direction === "up" ? "text-green-500" : "text-red-500"
              }`}>
                {STOCK_DATA.prediction.next5Days}
              </span>
              <div className="text-xs ml-2 bg-primary/10 px-2 py-0.5 rounded-full text-primary">
                {STOCK_DATA.prediction.confidence}% confidence
              </div>
            </div>
          </div>
          <Button>Add to Portfolio</Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 space-y-6">
          {/* Chart */}
          <StockChart
            symbol={STOCK_DATA.symbol}
            name={STOCK_DATA.name}
            startPrice={STOCK_DATA.price - 20}
            isUptrend={STOCK_DATA.change > 0}
          />

          {/* AI Model Explainer */}
          <ModelExplainer
            symbol={STOCK_DATA.symbol}
            name={STOCK_DATA.name}
            confidence={STOCK_DATA.prediction.confidence}
          />
        </div>

        <div className="space-y-6">
          {/* Fundamentals Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Fundamentals</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {Object.entries(STOCK_DATA.fundamentals).map(([key, value]) => (
                <div key={key} className="flex justify-between py-2 border-b last:border-0">
                  <span className="text-muted-foreground capitalize">{
                    key === "peRatio" ? "P/E Ratio" :
                    key === "marketCap" ? "Market Cap" :
                    key === "high52w" ? "52W High" :
                    key === "low52w" ? "52W Low" :
                    key === "avgVolume" ? "Avg Volume" :
                    key === "eps" ? "EPS" : key
                  }</span>
                  <span className="font-medium">{value}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Upcoming Events Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                Upcoming Events
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {STOCK_DATA.upcomingEvents.map((event) => (
                <div key={event.id} className="border rounded-lg p-3">
                  <div className="flex justify-between items-center">
                    <h4 className="font-medium">{event.name}</h4>
                    <div className="text-xs bg-primary/10 px-2 py-1 rounded-full text-primary">
                      {event.days} days
                    </div>
                  </div>
                  <div className="flex items-center mt-1 text-sm text-muted-foreground">
                    <Clock className="h-3 w-3 mr-1" />
                    {event.date}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Similar Stocks Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Similar Stocks</CardTitle>
              <CardDescription>Stocks in the same sector</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { symbol: "MSFT", name: "Microsoft Corp.", change: "+1.8%" },
                { symbol: "GOOG", name: "Alphabet Inc.", change: "+0.5%" },
                { symbol: "AMZN", name: "Amazon.com Inc.", change: "+2.1%" },
                { symbol: "META", name: "Meta Platforms Inc.", change: "-0.7%" },
              ].map((stock, index) => (
                <div key={stock.symbol} className="flex justify-between items-center py-2 border-b last:border-0">
                  <div>
                    <div className="font-medium">{stock.symbol}</div>
                    <div className="text-sm text-muted-foreground">{stock.name}</div>
                  </div>
                  <div className={stock.change.startsWith("+") ? "text-green-500" : "text-red-500"}>
                    {stock.change}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
