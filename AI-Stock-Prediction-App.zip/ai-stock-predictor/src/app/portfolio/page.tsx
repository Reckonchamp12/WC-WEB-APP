"use client";

import { useState } from "react";
import {
  CircleDollarSign,
  Briefcase,
  BarChart2,
  LineChart,
  Plus,
  Search
} from "lucide-react";
import { PortfolioSummary } from "@/components/portfolio/PortfolioSummary";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

// Mock portfolio data
const PORTFOLIO_DATA = {
  totalValue: 54892.67,
  totalGain: 7823.45,
  totalGainPercent: 16.62,
  holdings: [
    {
      symbol: "AAPL",
      name: "Apple Inc.",
      value: 12467.89,
      percentOfPortfolio: 22.71,
      change: 876.32,
      changePercent: 7.56,
      color: "#3b82f6"
    },
    {
      symbol: "MSFT",
      name: "Microsoft Corp.",
      value: 10234.56,
      percentOfPortfolio: 18.64,
      change: 1023.45,
      changePercent: 11.11,
      color: "#8b5cf6"
    },
    {
      symbol: "AMZN",
      name: "Amazon.com Inc.",
      value: 8765.43,
      percentOfPortfolio: 15.97,
      change: 567.89,
      changePercent: 6.93,
      color: "#f97316"
    },
    {
      symbol: "NVDA",
      name: "NVIDIA Corp.",
      value: 7654.32,
      percentOfPortfolio: 13.94,
      change: 2345.67,
      changePercent: 44.14,
      color: "#10b981"
    },
    {
      symbol: "GOOG",
      name: "Alphabet Inc.",
      value: 6543.21,
      percentOfPortfolio: 11.92,
      change: 432.10,
      changePercent: 7.07,
      color: "#ef4444"
    },
    {
      symbol: "META",
      name: "Meta Platforms Inc.",
      value: 5432.10,
      percentOfPortfolio: 9.90,
      change: 678.90,
      changePercent: 14.29,
      color: "#06b6d4"
    },
    {
      symbol: "TSLA",
      name: "Tesla, Inc.",
      value: 3795.16,
      percentOfPortfolio: 6.91,
      change: -100.89,
      changePercent: -2.59,
      color: "#a855f7"
    },
  ],
  simulationResults: [
    { id: 1, name: "Conservative", expectedReturn: 8.4, risk: "Low", aiConfidence: 82 },
    { id: 2, name: "Balanced", expectedReturn: 12.7, risk: "Medium", aiConfidence: 76 },
    { id: 3, name: "Aggressive", expectedReturn: 18.2, risk: "High", aiConfidence: 68 },
  ]
};

// Format currency
const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(value);
};

export default function PortfolioPage() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Portfolio Manager</h1>
          <p className="text-muted-foreground">
            Track, manage, and simulate your investment portfolio.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Add Stock
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add to Portfolio</DialogTitle>
                <DialogDescription>
                  Add a stock to your virtual portfolio.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium" htmlFor="symbol">Symbol</label>
                  <Input id="symbol" placeholder="e.g. AAPL" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium" htmlFor="shares">Number of Shares</label>
                  <Input id="shares" placeholder="e.g. 10" type="number" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium" htmlFor="price">Purchase Price</label>
                  <Input id="price" placeholder="e.g. 150.00" type="number" step="0.01" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium" htmlFor="date">Purchase Date</label>
                  <Input id="date" placeholder="e.g. 2023-04-01" type="date" />
                </div>
                <Button className="w-full">Add to Portfolio</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Portfolio Summary */}
      <PortfolioSummary
        totalValue={PORTFOLIO_DATA.totalValue}
        totalGain={PORTFOLIO_DATA.totalGain}
        totalGainPercent={PORTFOLIO_DATA.totalGainPercent}
        holdings={PORTFOLIO_DATA.holdings}
      />

      {/* Portfolio Analysis and Simulations */}
      <Tabs defaultValue="predictions" className="space-y-6">
        <TabsList>
          <TabsTrigger value="predictions" className="gap-2">
            <LineChart className="h-4 w-4" />
            AI Predictions
          </TabsTrigger>
          <TabsTrigger value="simulations" className="gap-2">
            <BarChart2 className="h-4 w-4" />
            Portfolio Simulations
          </TabsTrigger>
          <TabsTrigger value="optimization" className="gap-2">
            <Briefcase className="h-4 w-4" />
            Portfolio Optimization
          </TabsTrigger>
        </TabsList>

        {/* Predictions Tab */}
        <TabsContent value="predictions" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {PORTFOLIO_DATA.holdings.slice(0, 6).map((holding) => (
              <Card key={holding.symbol} className="hover:border-primary transition-colors">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{holding.symbol}</CardTitle>
                      <CardDescription>{holding.name}</CardDescription>
                    </div>
                    <CircleDollarSign className="h-8 w-8 text-primary opacity-70" />
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-muted-foreground">Current Value</div>
                      <div className="text-xl font-bold">{formatCurrency(holding.value)}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-muted-foreground">AI Prediction (30d)</div>
                      <div className={`text-xl font-medium ${
                        Math.random() > 0.3 ? "text-green-500" : "text-red-500"
                      }`}>
                        {Math.random() > 0.3 ? "+" : "-"}{(Math.random() * 10).toFixed(1)}%
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button size="sm" className="w-full">View Details</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Simulations Tab */}
        <TabsContent value="simulations" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-3">
            {PORTFOLIO_DATA.simulationResults.map((simulation) => (
              <Card key={simulation.id} className="hover:border-primary transition-colors">
                <CardHeader>
                  <CardTitle className="text-xl">{simulation.name}</CardTitle>
                  <CardDescription>
                    {simulation.risk} risk profile
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="text-sm text-muted-foreground">Expected Annual Return</div>
                    <div className="text-3xl font-bold text-green-500">+{simulation.expectedReturn}%</div>
                  </div>

                  <div>
                    <div className="text-sm text-muted-foreground">AI Confidence</div>
                    <div className="flex items-center">
                      <div className="w-full bg-muted rounded-full h-2.5 mr-2">
                        <div
                          className="bg-primary h-2.5 rounded-full"
                          style={{ width: `${simulation.aiConfidence}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium">{simulation.aiConfidence}%</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">View Simulation</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Optimization Tab */}
        <TabsContent value="optimization" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">AI Portfolio Optimization</CardTitle>
              <CardDescription>
                Our AI analyzes your portfolio and suggests optimizations to improve returns while managing risk.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border rounded-lg p-4 bg-muted/30">
                <h3 className="font-medium text-lg mb-2">Optimization Recommendations</h3>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <div className="bg-green-500/10 text-green-500 p-1 rounded mt-0.5">
                      <Plus className="h-4 w-4" />
                    </div>
                    <div>
                      <strong>Increase NVDA position</strong>
                      <p className="text-sm text-muted-foreground">Our AI predicts continued growth in this sector. Consider increasing allocation by 5%.</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="bg-red-500/10 text-red-500 p-1 rounded mt-0.5">
                      <LineChart className="h-4 w-4" />
                    </div>
                    <div>
                      <strong>Reduce TSLA exposure</strong>
                      <p className="text-sm text-muted-foreground">High volatility expected. Consider reducing position to manage portfolio risk.</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="bg-blue-500/10 text-blue-500 p-1 rounded mt-0.5">
                      <BarChart2 className="h-4 w-4" />
                    </div>
                    <div>
                      <strong>Sector Diversification</strong>
                      <p className="text-sm text-muted-foreground">Your portfolio is heavily weighted in tech. Consider adding healthcare or consumer staples.</p>
                    </div>
                  </li>
                </ul>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Run Advanced Optimization</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
