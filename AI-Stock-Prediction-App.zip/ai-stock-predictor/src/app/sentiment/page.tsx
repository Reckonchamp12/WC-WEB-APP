"use client";

import { useState } from "react";
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Search,
  ScanSearch
} from "lucide-react";
import { SentimentChart } from "@/components/sentiment/SentimentChart";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// Mock data for top sentiment stocks
const TOP_SENTIMENT_STOCKS = [
  { id: 1, symbol: "TSLA", name: "Tesla, Inc.", sentiment: 89, direction: "up", change: "+12%", sources: ["Twitter", "Reddit", "News"] },
  { id: 2, symbol: "AMD", name: "Advanced Micro Devices", sentiment: 76, direction: "up", change: "+5%", sources: ["Twitter", "Reddit"] },
  { id: 3, symbol: "PLTR", name: "Palantir Technologies", sentiment: 52, direction: "neutral", change: "-1%", sources: ["Twitter", "News"] },
  { id: 4, symbol: "META", name: "Meta Platforms Inc.", sentiment: 72, direction: "up", change: "+3%", sources: ["Twitter", "Reddit", "News"] },
  { id: 5, symbol: "NVDA", name: "NVIDIA Corporation", sentiment: 85, direction: "up", change: "+8%", sources: ["Twitter", "Reddit", "News"] },
  { id: 6, symbol: "AAPL", name: "Apple Inc.", sentiment: 65, direction: "up", change: "+2%", sources: ["Twitter", "News"] },
  { id: 7, symbol: "AMZN", name: "Amazon.com Inc.", sentiment: 68, direction: "up", change: "+3%", sources: ["Reddit", "News"] },
  { id: 8, symbol: "F", name: "Ford Motor Company", sentiment: 42, direction: "down", change: "-4%", sources: ["Twitter", "News"] },
];

// Mock data for trending topics
const TRENDING_TOPICS = [
  { topic: "AI Stocks", sentiment: 78, mentions: 1240 },
  { topic: "Fed Rate Cuts", sentiment: 65, mentions: 890 },
  { topic: "Earnings Season", sentiment: 58, mentions: 670 },
  { topic: "Semiconductor Chip Shortage", sentiment: 40, mentions: 520 },
  { topic: "Inflation Data", sentiment: 35, mentions: 480 },
];

export default function SentimentPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeStock, setActiveStock] = useState<string>("TSLA");
  const selectedStock = TOP_SENTIMENT_STOCKS.find(s => s.symbol === activeStock) || TOP_SENTIMENT_STOCKS[0];

  // Helper function to get sentiment color
  const getSentimentColor = (value: number) => {
    if (value >= 80) return "text-green-500";
    if (value >= 60) return "text-green-400";
    if (value >= 45) return "text-yellow-500";
    if (value >= 25) return "text-red-400";
    return "text-red-500";
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Sentiment Analysis</h1>
          <p className="text-muted-foreground">
            Real-time market sentiment across social media and news sources.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search for a stock or topic..."
              className="pl-8 w-full md:w-[280px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button>Search</Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 space-y-6">
          {/* Sentiment Chart */}
          <SentimentChart
            symbol={selectedStock.symbol}
            name={selectedStock.name}
          />

          {/* Trending Topics */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Trending Topics
              </CardTitle>
              <CardDescription>Market topics with the highest engagement</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {TRENDING_TOPICS.map((topic, index) => (
                  <div key={topic.topic} className="flex items-center justify-between border-b pb-3 last:border-0 last:pb-0">
                    <div>
                      <div className="font-medium">{topic.topic}</div>
                      <div className="text-sm text-muted-foreground">{topic.mentions.toLocaleString()} mentions</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className={`text-lg font-bold ${getSentimentColor(topic.sentiment)}`}>
                        {topic.sentiment}/100
                      </div>
                      <div className="w-16 bg-muted rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${
                            topic.sentiment >= 80 ? "bg-green-500" :
                            topic.sentiment >= 60 ? "bg-green-400" :
                            topic.sentiment >= 45 ? "bg-yellow-500" :
                            topic.sentiment >= 25 ? "bg-red-400" : "bg-red-500"
                          }`}
                          style={{ width: `${topic.sentiment}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {/* Top Sentiment Stocks */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                Top Sentiment Stocks
              </CardTitle>
              <CardDescription>Stocks with the highest social media sentiment</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex gap-1 overflow-x-auto pb-2">
                  {TOP_SENTIMENT_STOCKS.slice(0, 5).map((stock) => (
                    <Button
                      key={stock.id}
                      variant={activeStock === stock.symbol ? "default" : "outline"}
                      size="sm"
                      onClick={() => setActiveStock(stock.symbol)}
                    >
                      {stock.symbol}
                    </Button>
                  ))}
                </div>

                <div className="space-y-4">
                  {TOP_SENTIMENT_STOCKS.map((stock) => (
                    <div
                      key={stock.id}
                      className={`border rounded-lg p-3 cursor-pointer transition-colors ${
                        activeStock === stock.symbol ? "border-primary bg-primary/5" : "hover:border-primary/50"
                      }`}
                      onClick={() => setActiveStock(stock.symbol)}
                    >
                      <div className="flex justify-between items-center">
                        <div>
                          <div className="font-medium">{stock.symbol}</div>
                          <div className="text-sm text-muted-foreground">{stock.name}</div>
                        </div>
                        <div className="flex flex-col items-end">
                          <div className={`text-lg font-bold ${getSentimentColor(stock.sentiment)}`}>
                            {stock.sentiment}/100
                          </div>
                          <div className={`text-sm flex items-center ${
                            stock.direction === "up" ? "text-green-500" :
                            stock.direction === "down" ? "text-red-500" :
                            "text-yellow-500"
                          }`}>
                            {stock.direction === "up" ? <TrendingUp className="h-3 w-3 mr-1" /> :
                             stock.direction === "down" ? <TrendingDown className="h-3 w-3 mr-1" /> :
                             <ScanSearch className="h-3 w-3 mr-1" />}
                            {stock.change}
                          </div>
                        </div>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {stock.sources.map((source) => (
                          <div key={source} className="text-xs bg-primary/10 px-2 py-0.5 rounded-full text-primary">
                            {source}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
