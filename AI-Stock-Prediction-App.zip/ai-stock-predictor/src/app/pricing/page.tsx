"use client";

import { useState } from "react";
import { Check, HelpCircle } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

// Plan feature configuration
const plans = [
  {
    name: "Basic",
    description: "Essential tools for individual investors",
    price: { monthly: 9.99, annually: 99.99 },
    features: [
      { name: "Stock Price Predictions", included: true },
      { name: "Basic AI Analysis", included: true },
      { name: "Limited Portfolio Tracking (5 stocks)", included: true },
      { name: "Daily Market Updates", included: true },
      { name: "Trading Bot Access", included: false },
      { name: "Advanced Sentiment Analysis", included: false },
      { name: "Full Portfolio Optimization", included: false },
      { name: "API Access", included: false },
      { name: "Priority Support", included: false },
    ],
    ctaText: "Start Free Trial",
    popular: false,
  },
  {
    name: "Pro",
    description: "Advanced features for serious investors",
    price: { monthly: 29.99, annually: 299.99 },
    features: [
      { name: "Stock Price Predictions", included: true },
      { name: "Advanced AI Analysis", included: true },
      { name: "Unlimited Portfolio Tracking", included: true },
      { name: "Real-time Market Updates", included: true },
      { name: "Trading Bot Access", included: true },
      { name: "Advanced Sentiment Analysis", included: true },
      { name: "Basic Portfolio Optimization", included: true },
      { name: "API Access", included: false },
      { name: "Priority Support", included: false },
    ],
    ctaText: "Upgrade to Pro",
    popular: true,
  },
  {
    name: "Enterprise",
    description: "Comprehensive suite for professional investors",
    price: { monthly: 99.99, annually: 999.99 },
    features: [
      { name: "Stock Price Predictions", included: true },
      { name: "Advanced AI Analysis", included: true },
      { name: "Unlimited Portfolio Tracking", included: true },
      { name: "Real-time Market Updates", included: true },
      { name: "Trading Bot Access", included: true },
      { name: "Advanced Sentiment Analysis", included: true },
      { name: "Full Portfolio Optimization", included: true },
      { name: "API Access", included: true },
      { name: "Priority Support", included: true },
    ],
    ctaText: "Contact Sales",
    popular: false,
  },
];

// Feature tooltips
const featureTooltips = {
  "Stock Price Predictions": "AI-powered predictions for stock price movements",
  "Basic AI Analysis": "Fundamental analysis using machine learning",
  "Limited Portfolio Tracking (5 stocks)": "Track and analyze up to 5 stocks in your portfolio",
  "Daily Market Updates": "Daily digest of market movements and news",
  "Advanced AI Analysis": "In-depth analysis with multiple AI models and higher accuracy",
  "Unlimited Portfolio Tracking": "Track and analyze unlimited stocks in your portfolio",
  "Real-time Market Updates": "Live updates on market movements and breaking news",
  "Trading Bot Access": "Automated trading bot with customizable strategies",
  "Advanced Sentiment Analysis": "Deep sentiment analysis from social media and news sources",
  "Basic Portfolio Optimization": "AI recommendations for portfolio improvements",
  "Full Portfolio Optimization": "Advanced risk-adjusted portfolio optimization using multiple strategies",
  "API Access": "Programmatic access to all features and data",
  "Priority Support": "Dedicated support team with 24/7 availability",
};

export default function PricingPage() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annually">("monthly");

  return (
    <div className="container py-10 space-y-12">
      {/* Header */}
      <div className="text-center space-y-4 max-w-3xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
          Choose the Right Plan for Your Investment Journey
        </h1>
        <p className="text-xl text-muted-foreground">
          Unlock the power of AI-driven financial insights with our flexible pricing options
        </p>

        {/* Billing Cycle Selector */}
        <div className="flex items-center justify-center space-x-4 pt-4">
          <div className="flex items-center space-x-2">
            <Switch
              id="billing-cycle"
              checked={billingCycle === "annually"}
              onCheckedChange={(checked) => setBillingCycle(checked ? "annually" : "monthly")}
            />
            <Label htmlFor="billing-cycle" className="cursor-pointer">
              Bill annually{" "}
              <span className="text-xs text-primary font-medium ml-2 bg-primary/10 px-2 py-0.5 rounded-full">
                Save 15%
              </span>
            </Label>
          </div>
        </div>
      </div>

      {/* Pricing Cards */}
      <div className="grid md:grid-cols-3 gap-6">
        <TooltipProvider>
          {plans.map((plan) => (
            <Card
              key={plan.name}
              className={`border relative ${plan.popular ? "border-primary shadow-lg" : ""}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-primary text-primary-foreground text-xs font-medium px-3 py-1 rounded-full">
                  Most Popular
                </div>
              )}
              <CardHeader>
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <div className="flex items-baseline">
                    <span className="text-4xl font-bold">
                      ${billingCycle === "monthly" ? plan.price.monthly : plan.price.annually}
                    </span>
                    <span className="text-muted-foreground ml-2">
                      /{billingCycle === "monthly" ? "month" : "year"}
                    </span>
                  </div>
                  {billingCycle === "annually" && (
                    <p className="text-xs text-muted-foreground mt-1">
                      (${(plan.price.annually / 12).toFixed(2)} per month, billed annually)
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  {plan.features.map((feature) => (
                    <div key={feature.name} className="flex items-center">
                      <div className={`mr-2 ${feature.included ? "text-primary" : "text-muted-foreground"}`}>
                        {feature.included ? <Check className="h-4 w-4" /> : <div className="h-4 w-4" />}
                      </div>
                      <span className={feature.included ? "" : "text-muted-foreground"}>
                        {feature.name}
                      </span>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <HelpCircle className="h-3.5 w-3.5 ml-1 text-muted-foreground cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent side="top">
                          <p className="w-[200px] text-xs">{featureTooltips[feature.name as keyof typeof featureTooltips]}</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full"
                  variant={plan.popular ? "default" : "outline"}
                >
                  {plan.ctaText}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </TooltipProvider>
      </div>

      {/* FAQ Section */}
      <div className="mt-20 max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold text-center mb-8">Frequently Asked Questions</h2>
        <div className="space-y-6">
          <div className="space-y-2">
            <h3 className="text-lg font-medium">Can I upgrade or downgrade my plan at any time?</h3>
            <p className="text-muted-foreground">
              Yes, you can upgrade or downgrade your plan at any time. When upgrading, you'll be charged the prorated difference immediately. When downgrading, the change will apply at the end of your current billing cycle.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-medium">How accurate are the AI predictions?</h3>
            <p className="text-muted-foreground">
              Our AI models achieve an average accuracy of 65-75% in directional predictions, depending on the market conditions and time horizon. We transparently display confidence scores with all predictions.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-medium">Is there a free trial available?</h3>
            <p className="text-muted-foreground">
              Yes, all plans come with a 14-day free trial. No credit card is required to start, and you can cancel anytime during the trial period.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-medium">What payment methods do you accept?</h3>
            <p className="text-muted-foreground">
              We accept all major credit cards, PayPal, and for annual Enterprise plans, we can arrange bank transfers or invoicing.
            </p>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="mt-16 text-center">
        <div className="bg-primary/5 py-12 px-6 rounded-lg border max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold mb-4">Ready to transform your investment strategy?</h2>
          <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto">
            Join thousands of investors using Walford Capitals' AI-powered tools to make smarter investment decisions.
          </p>
          <Button size="lg">Get Started Today</Button>
        </div>
      </div>
    </div>
  );
}
