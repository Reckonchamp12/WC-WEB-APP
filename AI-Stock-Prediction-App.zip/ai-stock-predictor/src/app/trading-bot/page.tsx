"use client";

import { useState } from "react";
import {
  Bot,
  ArrowRight,
  PlayCircle,
  PauseCircle,
  RotateCcw,
  Copy,
  Settings,
  ChevronRight,
  LineChart,
  TrendingUp,
  TrendingDown,
  BarChart,
  Zap,
  AlertTriangle,
  DollarSign,
  Link,
  PlusCircle
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

// Mock data for active bots
const ACTIVE_BOTS = [
  {
    id: 1,
    name: "MACD Swing Trader",
    status: "active",
    marketType: "stocks",
    symbols: ["AAPL", "MSFT", "GOOGL", "AMZN"],
    pnl: "+12.4%",
    pnlValue: "+$1,243.67",
    trades: 14,
    winRate: "72%",
    lastUpdated: "5 minutes ago"
  },
  {
    id: 2,
    name: "RSI Reversal Pro",
    status: "active",
    marketType: "stocks",
    symbols: ["NVDA", "AMD", "INTC", "TSLA"],
    pnl: "+8.2%",
    pnlValue: "+$820.35",
    trades: 9,
    winRate: "67%",
    lastUpdated: "12 minutes ago"
  },
  {
    id: 3,
    name: "Bollinger Bands Breakout",
    status: "paused",
    marketType: "crypto",
    symbols: ["BTC/USD", "ETH/USD", "SOL/USD"],
    pnl: "-2.1%",
    pnlValue: "-$210.50",
    trades: 6,
    winRate: "33%",
    lastUpdated: "1 hour ago"
  },
];

// Mock data for strategy templates
const STRATEGY_TEMPLATES = [
  {
    id: 1,
    name: "Golden Cross Strategy",
    description: "Uses 50-day and 200-day moving average crossovers to identify long-term trend changes.",
    complexity: "Beginner",
    performance: {
      backtest: "+18.4%",
      sharpe: 1.34,
      maxDrawdown: "-12.6%"
    },
    marketTypes: ["stocks", "etfs"],
    indicators: ["Moving Average", "Volume"],
    popularity: 4.7
  },
  {
    id: 2,
    name: "RSI Overbought/Oversold",
    description: "Identifies potential reversal points when RSI indicates overbought or oversold conditions.",
    complexity: "Beginner",
    performance: {
      backtest: "+22.1%",
      sharpe: 1.62,
      maxDrawdown: "-15.3%"
    },
    marketTypes: ["stocks", "forex", "crypto"],
    indicators: ["RSI", "Volume", "Moving Average"],
    popularity: 4.8
  },
  {
    id: 3,
    name: "MACD Momentum Strategy",
    description: "Uses MACD crossovers and histogram changes to identify momentum shifts in price action.",
    complexity: "Intermediate",
    performance: {
      backtest: "+24.7%",
      sharpe: 1.78,
      maxDrawdown: "-18.9%"
    },
    marketTypes: ["stocks", "crypto", "futures"],
    indicators: ["MACD", "Volume", "Moving Average"],
    popularity: 4.5
  },
  {
    id: 4,
    name: "Bollinger Band Squeeze",
    description: "Identifies periods of low volatility followed by breakouts for potential strong trends.",
    complexity: "Intermediate",
    performance: {
      backtest: "+19.8%",
      sharpe: 1.41,
      maxDrawdown: "-14.2%"
    },
    marketTypes: ["stocks", "forex", "crypto"],
    indicators: ["Bollinger Bands", "Volume", "ATR"],
    popularity: 4.3
  },
  {
    id: 5,
    name: "AI-Enhanced Market Regime",
    description: "Uses machine learning to detect market regimes (trend, range, volatile) and adapts strategy accordingly.",
    complexity: "Advanced",
    performance: {
      backtest: "+31.2%",
      sharpe: 2.05,
      maxDrawdown: "-16.8%"
    },
    marketTypes: ["stocks", "etfs", "crypto", "futures"],
    indicators: ["AI Model", "Multiple Technicals", "Sentiment"],
    popularity: 4.9
  },
];

export default function TradingBotPage() {
  const [activeTab, setActiveTab] = useState("dashboard");

  return (
    <div className="container py-6 space-y-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">AI Trading Bot</h1>
          <p className="text-muted-foreground">
            Build, test, and deploy automated trading strategies with no code
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="gap-1">
            <PlusCircle className="h-4 w-4" />
            New Bot
          </Button>
          <Button className="gap-1">
            <Zap className="h-4 w-4" />
            AI Generate
          </Button>
        </div>
      </div>

      <Tabs defaultValue="dashboard" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 md:w-auto">
          <TabsTrigger value="dashboard" className="gap-2">
            <BarChart className="h-4 w-4 hidden sm:block" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="builder" className="gap-2">
            <Bot className="h-4 w-4 hidden sm:block" />
            Bot Builder
          </TabsTrigger>
          <TabsTrigger value="backtest" className="gap-2">
            <RotateCcw className="h-4 w-4 hidden sm:block" />
            Backtest
          </TabsTrigger>
          <TabsTrigger value="marketplace" className="gap-2">
            <Link className="h-4 w-4 hidden sm:block" />
            Marketplace
          </TabsTrigger>
        </TabsList>

        {/* Dashboard Tab */}
        <TabsContent value="dashboard" className="space-y-6">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between py-4">
                <CardTitle className="text-sm font-medium">Active Bots</CardTitle>
                <Bot className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3 / 5</div>
                <p className="text-xs text-muted-foreground">Pro plan limit</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between py-4">
                <CardTitle className="text-sm font-medium">Total P&L (30d)</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-500">+$1,853.52</div>
                <p className="text-xs text-green-500">+14.2% return</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between py-4">
                <CardTitle className="text-sm font-medium">Total Trades</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">29</div>
                <p className="text-xs text-muted-foreground">68% win rate</p>
              </CardContent>
            </Card>
          </div>

          <h2 className="text-xl font-semibold mt-8 mb-4">Your Trading Bots</h2>
          <div className="space-y-4">
            {ACTIVE_BOTS.map((bot) => (
              <Card key={bot.id} className="overflow-hidden border hover:border-primary transition-colors">
                <div className={`h-1.5 w-full ${
                  bot.status === "active"
                    ? "bg-green-500"
                    : bot.status === "paused"
                    ? "bg-amber-500"
                    : "bg-red-500"
                }`} />
                <CardHeader className="py-4">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <CardTitle className="text-lg">{bot.name}</CardTitle>
                        <Badge variant={bot.status === "active" ? "default" : "outline"}>
                          {bot.status === "active" ? "Active" : "Paused"}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                        <Badge variant="outline" className="capitalize">
                          {bot.marketType}
                        </Badge>
                        <span className="text-xs">
                          {bot.symbols.slice(0, 2).join(", ")}
                          {bot.symbols.length > 2 ? ` +${bot.symbols.length - 2} more` : ""}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className={`text-right ${
                        bot.pnl.startsWith("+") ? "text-green-500" : "text-red-500"
                      }`}>
                        <div className="font-bold">
                          {bot.pnlValue}
                        </div>
                        <div className="text-xs">
                          {bot.pnl} • {bot.trades} trades
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {bot.status === "active" ? (
                          <Button variant="outline" size="icon" title="Pause Bot">
                            <PauseCircle className="h-4 w-4" />
                          </Button>
                        ) : (
                          <Button variant="outline" size="icon" title="Start Bot">
                            <PlayCircle className="h-4 w-4" />
                          </Button>
                        )}
                        <Button variant="outline" size="icon" title="Bot Settings">
                          <Settings className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="icon" title="Clone Bot">
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="py-0 grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Win Rate</p>
                    <p className="font-medium">{bot.winRate}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Total Trades</p>
                    <p className="font-medium">{bot.trades}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Last Update</p>
                    <p className="font-medium">{bot.lastUpdated}</p>
                  </div>
                  <div className="flex items-center justify-end md:justify-start">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs h-8 px-2 gap-1"
                    >
                      View Details
                      <ChevronRight className="h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Bot Builder Tab */}
        <TabsContent value="builder" className="space-y-6">
          <div className="bg-primary/5 p-6 rounded-lg border border-dashed border-primary">
            <div className="flex flex-col items-center text-center space-y-2 max-w-md mx-auto">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-2">
                <Bot className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">The No-Code Bot Builder</h3>
              <p className="text-muted-foreground">
                Create sophisticated trading strategies without writing code. Drag and drop indicators, set conditions, and build your perfect bot.
              </p>
              <div className="pt-4 space-x-4">
                <Button className="gap-1">
                  <PlusCircle className="h-4 w-4" />
                  New Strategy
                </Button>
                <Button variant="outline" className="gap-1">
                  <Zap className="h-4 w-4" />
                  AI Generate
                </Button>
              </div>
            </div>
          </div>

          <h2 className="text-xl font-semibold mt-8">Strategy Templates</h2>
          <p className="text-muted-foreground -mt-2 mb-4">
            Start with a pre-built strategy and customize it to your needs
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {STRATEGY_TEMPLATES.map((strategy) => (
              <Card key={strategy.id} className="hover:border-primary transition-colors">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{strategy.name}</CardTitle>
                    <Badge variant="outline" className="font-normal">
                      {strategy.complexity}
                    </Badge>
                  </div>
                  <CardDescription className="line-clamp-2">
                    {strategy.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="grid grid-cols-3 gap-2 text-sm">
                    <div>
                      <p className="text-xs text-muted-foreground">Backtest Return</p>
                      <p className="font-medium text-green-500">{strategy.performance.backtest}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Sharpe Ratio</p>
                      <p className="font-medium">{strategy.performance.sharpe}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Max Drawdown</p>
                      <p className="font-medium text-red-500">{strategy.performance.maxDrawdown}</p>
                    </div>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-1">
                    {strategy.marketTypes.map((market) => (
                      <Badge key={market} variant="secondary" className="capitalize text-xs">
                        {market}
                      </Badge>
                    ))}
                    {strategy.indicators.map((indicator) => (
                      <Badge key={indicator} variant="outline" className="text-xs">
                        {indicator}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div className="flex items-center">
                    <div className="flex items-center mr-2">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <span key={i} className={`text-xs ${i < Math.floor(strategy.popularity) ? "text-amber-400" : "text-muted-foreground"}`}>
                          ★
                        </span>
                      ))}
                    </div>
                    <span className="text-xs text-muted-foreground">{strategy.popularity}/5</span>
                  </div>
                  <Button size="sm">Use Template</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Backtest Tab - Simplified UI */}
        <TabsContent value="backtest" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Backtest Your Strategy</CardTitle>
              <CardDescription>
                Test your trading strategy against historical data to evaluate its performance
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="strategy">Select Strategy</Label>
                  <select id="strategy" className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background">
                    <option value="">Select a strategy...</option>
                    <option value="macd-swing">MACD Swing Trader</option>
                    <option value="rsi-reversal">RSI Reversal Pro</option>
                    <option value="bollinger">Bollinger Bands Breakout</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="symbol">Symbol</Label>
                  <Input id="symbol" placeholder="e.g. AAPL, MSFT, GOOGL" />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="start-date">Start Date</Label>
                  <Input id="start-date" type="date" defaultValue="2022-01-01" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="end-date">End Date</Label>
                  <Input id="end-date" type="date" defaultValue="2023-01-01" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="initial-capital">Initial Capital</Label>
                  <Input id="initial-capital" type="number" defaultValue="10000" />
                </div>
              </div>

              <div className="flex flex-wrap gap-4">
                <div className="space-y-2 flex-1">
                  <Label className="flex items-center gap-2">
                    <Switch id="use-margin" />
                    <span>Use Margin</span>
                  </Label>
                </div>
                <div className="space-y-2 flex-1">
                  <Label className="flex items-center gap-2">
                    <Switch id="account-for-slippage" defaultChecked />
                    <span>Account for Slippage</span>
                  </Label>
                </div>
                <div className="space-y-2 flex-1">
                  <Label className="flex items-center gap-2">
                    <Switch id="include-commissions" defaultChecked />
                    <span>Include Commissions</span>
                  </Label>
                </div>
              </div>

              <div className="pt-4">
                <Button className="w-full sm:w-auto">
                  Run Backtest
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Backtests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                    <div>
                      <p className="font-medium">MACD Swing (AAPL)</p>
                      <p className="text-xs text-muted-foreground">Jan 2022 - Dec 2022</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-green-500">+24.32%</p>
                      <p className="text-xs text-muted-foreground">Sharpe: 1.43</p>
                    </div>
                  </div>
                  <div className="flex justify-between items-center p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                    <div>
                      <p className="font-medium">RSI Reversal (MSFT)</p>
                      <p className="text-xs text-muted-foreground">Jan 2022 - Dec 2022</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-red-500">-5.67%</p>
                      <p className="text-xs text-muted-foreground">Sharpe: 0.32</p>
                    </div>
                  </div>
                  <div className="flex justify-between items-center p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                    <div>
                      <p className="font-medium">Golden Cross (QQQ)</p>
                      <p className="text-xs text-muted-foreground">Jan 2022 - Dec 2022</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-green-500">+17.88%</p>
                      <p className="text-xs text-muted-foreground">Sharpe: 1.27</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">AI Strategy Suggestions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-purple-300 dark:border-purple-800">
                    <div className="flex items-center gap-2 mb-2">
                      <Zap className="h-5 w-5 text-purple-500" />
                      <h3 className="font-medium">Based on your portfolio</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      Your tech-heavy portfolio could benefit from a momentum strategy with volatility filters.
                    </p>
                    <Button size="sm" variant="outline" className="gap-1 text-xs">
                      <Bot className="h-3 w-3" />
                      Generate Strategy
                    </Button>
                  </div>

                  <div className="p-4 border rounded-lg bg-gradient-to-r from-amber-500/10 to-orange-500/10 border-amber-300 dark:border-amber-800">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="h-5 w-5 text-amber-500" />
                      <h3 className="font-medium">Market Condition Alert</h3>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      Current volatility suggests adapting your strategies with tighter stops and smaller position sizes.
                    </p>
                    <Button size="sm" variant="outline" className="gap-1 text-xs">
                      <Bot className="h-3 w-3" />
                      Adapt Strategies
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Marketplace Tab */}
        <TabsContent value="marketplace" className="space-y-6">
          <div className="grid grid-cols-1 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Strategy Marketplace</CardTitle>
                <CardDescription>
                  Browse, buy, and clone trading strategies created by experts and the community
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 space-y-4">
                  <div className="bg-primary/10 h-16 w-16 rounded-full mx-auto flex items-center justify-center">
                    <Link className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-medium">Coming Soon</h3>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    Our marketplace is in development. Soon you'll be able to share, sell, and purchase proven trading strategies.
                  </p>
                  <Button variant="outline">Join Waitlist</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
