import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import ClientBody from "./ClientBody";
import { ThemeProvider } from "@/components/layout/ThemeProvider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AI Stock Predictor - Market Insights & Predictions",
  description: "Advanced AI-driven stock price predictions, market sentiment analysis, and portfolio management for retail and professional investors.",
  keywords: "AI, stock predictions, sentiment analysis, market trends, portfolio management, machine learning",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${geistSans.variable} ${geistMono.variable}`} suppressHydrationWarning>
      <ThemeProvider>
        <ClientBody>{children}</ClientBody>
      </ThemeProvider>
    </html>
  );
}
