"use client";

import { useState } from "react";
import {
  ArrowUpRight,
  ArrowDownRight,
  BarChart3,
  LineChart,
  TrendingUp,
  CircleDollarSign,
  Clock,
  Search
} from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// This would come from an API in a real app
const MOCK_MARKET_DATA = {
  marketIndices: [
    { id: 1, name: "S&P 500", value: "5,127.53", change: "+0.43%", direction: "up" },
    { id: 2, name: "Nasdaq", value: "16,048.39", change: "+0.72%", direction: "up" },
    { id: 3, name: "Dow Jones", value: "38,997.66", change: "-0.18%", direction: "down" },
    { id: 4, name: "Russell 2000", value: "2,042.55", change: "+0.51%", direction: "up" },
  ],
  topPredictions: [
    { id: 1, symbol: "AAPL", name: "Apple Inc.", prediction: "+2.3%", confidence: "87%" },
    { id: 2, symbol: "MSFT", name: "Microsoft Corp.", prediction: "+1.8%", confidence: "84%" },
    { id: 3, symbol: "AMZN", name: "Amazon.com Inc.", prediction: "+4.1%", confidence: "78%" },
    { id: 4, symbol: "NVDA", name: "NVIDIA Corp.", prediction: "+3.7%", confidence: "82%" },
    { id: 5, symbol: "GOOG", name: "Alphabet Inc.", prediction: "+1.2%", confidence: "76%" },
  ],
  topSentiment: [
    { id: 1, symbol: "TSLA", name: "Tesla Inc.", sentiment: "Very Positive", score: "89" },
    { id: 2, symbol: "AMD", name: "Advanced Micro Devices", sentiment: "Positive", score: "76" },
    { id: 3, symbol: "PLTR", name: "Palantir Technologies", sentiment: "Neutral", score: "52" },
    { id: 4, symbol: "META", name: "Meta Platforms Inc.", sentiment: "Positive", score: "72" },
    { id: 5, symbol: "NFLX", name: "Netflix Inc.", sentiment: "Positive", score: "68" },
  ],
  recentNews: [
    { id: 1, title: "Fed signals potential rate cuts coming soon", time: "2 hours ago", source: "Market News" },
    { id: 2, title: "Tech stocks rally on strong earnings reports", time: "4 hours ago", source: "Financial Times" },
    { id: 3, title: "Inflation data comes in lower than expected", time: "6 hours ago", source: "Reuters" },
    { id: 4, title: "Major bank announces strong quarterly earnings", time: "8 hours ago", source: "CNBC" },
  ]
};

export default function DashboardPage() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            Your market overview and AI-powered insights.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search for a stock..."
              className="pl-8 w-full md:w-[260px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button>Search</Button>
        </div>
      </div>

      {/* Market Summary */}
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        {MOCK_MARKET_DATA.marketIndices.map((index) => (
          <Card key={index.id}>
            <CardHeader className="flex flex-row items-center justify-between py-4">
              <CardTitle className="text-sm font-medium">{index.name}</CardTitle>
              {index.direction === "up" ? (
                <ArrowUpRight className="h-4 w-4 text-green-500" />
              ) : (
                <ArrowDownRight className="h-4 w-4 text-red-500" />
              )}
            </CardHeader>
            <CardContent className="py-2">
              <div className="text-2xl font-bold">{index.value}</div>
              <p className={`text-xs ${
                index.direction === "up" ? "text-green-500" : "text-red-500"
              }`}>
                {index.change}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content */}
      <Tabs defaultValue="predictions" className="space-y-6">
        <TabsList>
          <TabsTrigger value="predictions" className="gap-2">
            <LineChart className="h-4 w-4" />
            Predictions
          </TabsTrigger>
          <TabsTrigger value="sentiment" className="gap-2">
            <BarChart3 className="h-4 w-4" />
            Sentiment
          </TabsTrigger>
          <TabsTrigger value="news" className="gap-2">
            <TrendingUp className="h-4 w-4" />
            Market News
          </TabsTrigger>
        </TabsList>

        {/* Predictions Tab */}
        <TabsContent value="predictions" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {MOCK_MARKET_DATA.topPredictions.map((prediction) => (
              <Card key={prediction.id} className="hover:border-primary transition-colors">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{prediction.symbol}</CardTitle>
                      <CardDescription>{prediction.name}</CardDescription>
                    </div>
                    <CircleDollarSign className="h-8 w-8 text-primary opacity-70" />
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-muted-foreground">Predicted Change (5d)</div>
                      <div className="text-2xl font-bold text-green-500">{prediction.prediction}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-muted-foreground">Confidence</div>
                      <div className="text-xl font-medium">{prediction.confidence}</div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button size="sm" className="w-full">View Details</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Sentiment Tab */}
        <TabsContent value="sentiment" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {MOCK_MARKET_DATA.topSentiment.map((item) => (
              <Card key={item.id} className="hover:border-primary transition-colors">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{item.symbol}</CardTitle>
                      <CardDescription>{item.name}</CardDescription>
                    </div>
                    <BarChart3 className="h-8 w-8 text-primary opacity-70" />
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-muted-foreground">Market Sentiment</div>
                      <div className="text-xl font-bold">{item.sentiment}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-muted-foreground">Score</div>
                      <div className="text-xl font-medium">{item.score}/100</div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button size="sm" className="w-full">View Details</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* News Tab */}
        <TabsContent value="news" className="space-y-6">
          <div className="grid gap-4">
            {MOCK_MARKET_DATA.recentNews.map((news) => (
              <Card key={news.id} className="hover:border-primary transition-colors">
                <CardHeader className="py-4">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">{news.title}</CardTitle>
                    <div className="flex items-center text-muted-foreground text-sm">
                      <Clock className="h-3 w-3 mr-1" />
                      {news.time}
                    </div>
                  </div>
                </CardHeader>
                <CardFooter className="py-3 border-t">
                  <div className="flex items-center justify-between w-full">
                    <span className="text-sm text-muted-foreground">{news.source}</span>
                    <Button variant="ghost" size="sm">Read More</Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
