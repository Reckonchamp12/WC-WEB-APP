"use client";

import { useState } from "react";
import {
  Newspaper,
  Calendar,
  Clock,
  TrendingUp,
  ExternalLink,
  Search,
  CircleDollarSign,
  Filter
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

// Mock news data
const NEWS_DATA = {
  featuredNews: [
    {
      id: 1,
      title: "Federal Reserve Signals Potential Rate Cuts in Coming Months",
      summary: "Federal Reserve Chair Jerome Powell indicated the central bank could begin cutting interest rates if inflation continues to moderate, potentially as early as September.",
      source: "Financial Times",
      time: "2 hours ago",
      category: "Economy",
      image: "https://images.unsplash.com/photo-1621375311864-162155dd2c94?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3"
    },
    {
      id: 2,
      title: "Tech Stocks Rally on Strong Earnings and AI Optimism",
      summary: "The technology sector led a broad market rally after several major companies reported better-than-expected earnings, with artificial intelligence initiatives driving future growth outlook.",
      source: "Market Watch",
      time: "4 hours ago",
      category: "Markets",
      image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3"
    }
  ],
  recentNews: [
    {
      id: 3,
      title: "Inflation Data Comes in Lower Than Expected",
      summary: "Latest Consumer Price Index data showed inflation easing to 2.9%, below analyst expectations, boosting market hopes for monetary policy easing.",
      source: "Reuters",
      time: "6 hours ago",
      category: "Economy"
    },
    {
      id: 4,
      title: "Major Bank Announces Strong Quarterly Earnings",
      summary: "One of the nation's largest banks reported earnings that beat analyst expectations, driven by strong consumer banking and wealth management divisions.",
      source: "Bloomberg",
      time: "8 hours ago",
      category: "Finance"
    },
    {
      id: 5,
      title: "Oil Prices Rise Amid Middle East Tensions",
      summary: "Crude oil futures climbed over 3% as geopolitical tensions raised concerns about potential supply disruptions in the Middle East region.",
      source: "CNBC",
      time: "10 hours ago",
      category: "Commodities"
    },
    {
      id: 6,
      title: "Retail Sales Exceed Forecasts in Latest Report",
      summary: "Consumer spending showed resilience in the latest retail sales report, suggesting economic growth remains robust despite inflation concerns.",
      source: "Wall Street Journal",
      time: "1 day ago",
      category: "Economy"
    },
    {
      id: 7,
      title: "Tech Giant Announces Major AI Product Launch",
      summary: "One of the world's leading technology companies unveiled its latest artificial intelligence platform, targeting enterprise customers with advanced machine learning capabilities.",
      source: "TechCrunch",
      time: "1 day ago",
      category: "Technology"
    }
  ],
  marketInsights: [
    {
      id: 1,
      title: "Tech Sector Analysis: Growth Opportunities in AI and Cloud Computing",
      summary: "Our AI models identify significant growth potential in select technology companies leveraging artificial intelligence and cloud infrastructure.",
      trend: "bullish",
      confidence: 84
    },
    {
      id: 2,
      title: "Energy Sector Outlook: Transitioning to Renewables",
      summary: "Traditional energy companies with strong renewable energy investments are positioned well for the ongoing energy transition.",
      trend: "neutral",
      confidence: 76
    },
    {
      id: 3,
      title: "Consumer Discretionary: Headwinds from Inflation Pressures",
      summary: "Rising costs and potential rate-sensitive consumer spending may impact profit margins in the discretionary retail sector.",
      trend: "bearish",
      confidence: 68
    }
  ]
};

export default function NewsPage() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Market News & Insights</h1>
          <p className="text-muted-foreground">
            Financial news and AI-powered market insights.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search news..."
              className="pl-8 w-full md:w-[260px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Featured News */}
      <div className="grid gap-6 md:grid-cols-2">
        {NEWS_DATA.featuredNews.map((news) => (
          <Card key={news.id} className="overflow-hidden">
            <div className="h-48 relative">
              <img
                src={news.image}
                alt={news.title}
                className="object-cover w-full h-full"
              />
              <div className="absolute top-3 left-3">
                <Badge className="bg-primary hover:bg-primary">{news.category}</Badge>
              </div>
            </div>
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">{news.title}</CardTitle>
              <div className="flex items-center text-muted-foreground text-sm">
                <Clock className="h-3 w-3 mr-1" />
                {news.time} • {news.source}
              </div>
            </CardHeader>
            <CardContent className="pb-3">
              <p className="text-muted-foreground">{news.summary}</p>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full gap-2">
                Read Full Article
                <ExternalLink className="h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {/* Tabs for Regular News and AI Insights */}
      <Tabs defaultValue="recent" className="space-y-6">
        <TabsList>
          <TabsTrigger value="recent" className="gap-2">
            <Newspaper className="h-4 w-4" />
            Recent News
          </TabsTrigger>
          <TabsTrigger value="insights" className="gap-2">
            <TrendingUp className="h-4 w-4" />
            AI Market Insights
          </TabsTrigger>
        </TabsList>

        {/* Recent News Tab */}
        <TabsContent value="recent" className="space-y-4">
          {NEWS_DATA.recentNews.map((news) => (
            <Card key={news.id} className="hover:border-primary transition-colors">
              <CardHeader className="py-4">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline">{news.category}</Badge>
                      <div className="flex items-center text-muted-foreground text-sm">
                        <Clock className="h-3 w-3 mr-1" />
                        {news.time}
                      </div>
                    </div>
                    <CardTitle className="text-lg">{news.title}</CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="py-0">
                <p className="text-muted-foreground">{news.summary}</p>
              </CardContent>
              <CardFooter className="py-3 flex justify-between">
                <span className="text-sm text-muted-foreground">{news.source}</span>
                <Button variant="ghost" size="sm" className="gap-1">
                  Read More
                  <ExternalLink className="h-3 w-3" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </TabsContent>

        {/* AI Market Insights Tab */}
        <TabsContent value="insights" className="space-y-6">
          <div className="bg-primary/5 p-4 rounded-lg border">
            <div className="flex items-center gap-3 mb-3">
              <CircleDollarSign className="h-6 w-6 text-primary" />
              <div>
                <h3 className="font-medium">AI-Powered Market Insights</h3>
                <p className="text-sm text-muted-foreground">Insights generated by our advanced machine learning models, analyzing market trends, news sentiment, and technical factors.</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            {NEWS_DATA.marketInsights.map((insight) => (
              <Card key={insight.id} className="hover:border-primary transition-colors">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{insight.title}</CardTitle>
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                      insight.trend === "bullish" ? "bg-green-500/10 text-green-500" :
                      insight.trend === "bearish" ? "bg-red-500/10 text-red-500" :
                      "bg-yellow-500/10 text-yellow-500"
                    }`}>
                      {insight.trend.charAt(0).toUpperCase() + insight.trend.slice(1)} Trend
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pb-3">
                  <p className="text-muted-foreground">{insight.summary}</p>
                </CardContent>
                <CardFooter className="py-3 flex justify-between items-center border-t">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">AI Confidence:</span>
                    <div className="w-20 bg-muted rounded-full h-1.5">
                      <div
                        className="bg-primary h-1.5 rounded-full"
                        style={{ width: `${insight.confidence}%` }}
                      />
                    </div>
                    <span className="text-sm font-medium">{insight.confidence}%</span>
                  </div>
                  <Button size="sm">View Analysis</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
