"use client";

import { useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  Area,
  AreaChart,
} from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

// Mock data generator
const generateSentimentData = (days: number, volatility = 15) => {
  const data = [];
  let twitterSentiment = 65; // Start at neutral-positive
  let redditSentiment = 60;
  let newsSentiment = 55;

  for (let i = 0; i < days; i++) {
    // Random fluctuations in sentiment
    twitterSentiment += (Math.random() * volatility * 2) - volatility;
    redditSentiment += (Math.random() * volatility * 2) - volatility;
    newsSentiment += (Math.random() * volatility * 2) - volatility;

    // Keep within bounds (0-100)
    twitterSentiment = Math.min(100, Math.max(0, twitterSentiment));
    redditSentiment = Math.min(100, Math.max(0, redditSentiment));
    newsSentiment = Math.min(100, Math.max(0, newsSentiment));

    // Combine with weighted average
    const combinedSentiment = (twitterSentiment * 0.4 + redditSentiment * 0.3 + newsSentiment * 0.3);

    // Create date
    const date = new Date();
    date.setDate(date.getDate() - (days - i - 1));

    data.push({
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      twitter: Math.round(twitterSentiment),
      reddit: Math.round(redditSentiment),
      news: Math.round(newsSentiment),
      combined: Math.round(combinedSentiment),
    });
  }

  return data;
};

type TimeframeOption = '1W' | '2W' | '1M' | '3M';

interface SentimentChartProps {
  symbol: string;
  name: string;
}

export function SentimentChart({ symbol, name }: SentimentChartProps) {
  const [timeframe, setTimeframe] = useState<TimeframeOption>('2W');

  // Get appropriate number of days based on timeframe
  const getDays = () => {
    switch (timeframe) {
      case '1W': return 7;
      case '2W': return 14;
      case '1M': return 30;
      case '3M': return 90;
      default: return 14;
    }
  };

  const data = generateSentimentData(getDays());

  // Calculate current sentiment (last data point)
  const currentSentiment = data[data.length - 1].combined;

  // Get sentiment description based on value
  const getSentimentDescription = (value: number) => {
    if (value >= 80) return "Very Positive";
    if (value >= 60) return "Positive";
    if (value >= 45) return "Neutral";
    if (value >= 25) return "Negative";
    return "Very Negative";
  };

  // Get sentiment color based on value
  const getSentimentColor = (value: number) => {
    if (value >= 80) return "text-green-500";
    if (value >= 60) return "text-green-400";
    if (value >= 45) return "text-yellow-500";
    if (value >= 25) return "text-red-400";
    return "text-red-500";
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <CardTitle className="text-2xl">{symbol} Sentiment Analysis</CardTitle>
            <CardDescription>Social media and news sentiment for {name}</CardDescription>
          </div>
          <div className="flex items-center space-x-2">
            {(['1W', '2W', '1M', '3M'] as TimeframeOption[]).map((option) => (
              <Button
                key={option}
                variant={timeframe === option ? "default" : "outline"}
                size="sm"
                onClick={() => setTimeframe(option)}
              >
                {option}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
          <div className="bg-primary/5 px-4 py-3 rounded-lg">
            <div className="text-sm text-muted-foreground">Current Sentiment</div>
            <div className="flex items-center gap-2">
              <span className={`text-2xl font-bold ${getSentimentColor(currentSentiment)}`}>
                {getSentimentDescription(currentSentiment)}
              </span>
              <span className="text-sm bg-primary/10 px-2 py-0.5 rounded-full text-primary">
                {currentSentiment}/100
              </span>
            </div>
          </div>

          <div className="flex space-x-4">
            <div className="flex items-center gap-1">
              <div className="h-3 w-3 rounded-full bg-blue-400" />
              <span className="text-sm text-muted-foreground">Twitter</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="h-3 w-3 rounded-full bg-orange-400" />
              <span className="text-sm text-muted-foreground">Reddit</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="h-3 w-3 rounded-full bg-green-400" />
              <span className="text-sm text-muted-foreground">News</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="h-3 w-3 rounded-full bg-purple-400" />
              <span className="text-sm text-muted-foreground">Combined</span>
            </div>
          </div>
        </div>

        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data}
              margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="date" />
              <YAxis domain={[0, 100]} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'var(--background)',
                  borderColor: 'var(--border)',
                  borderRadius: '8px'
                }}
                formatter={(value: number) => [`${value}/100`, ""]}
                labelStyle={{ color: 'var(--foreground)' }}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="twitter"
                stroke="#3b82f6"
                strokeWidth={2}
                dot={false}
                name="Twitter"
              />
              <Line
                type="monotone"
                dataKey="reddit"
                stroke="#f97316"
                strokeWidth={2}
                dot={false}
                name="Reddit"
              />
              <Line
                type="monotone"
                dataKey="news"
                stroke="#22c55e"
                strokeWidth={2}
                dot={false}
                name="News"
              />
              <Line
                type="monotone"
                dataKey="combined"
                stroke="#a855f7"
                strokeWidth={3}
                dot={{ r: 3 }}
                activeDot={{ r: 6 }}
                name="Combined"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-muted/50 p-4 rounded-lg">
          <h4 className="font-medium mb-2">How to interpret sentiment scores:</h4>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li><span className="text-green-500 font-medium">80-100:</span> Very Positive - Strong bullish sentiment</li>
            <li><span className="text-green-400 font-medium">60-79:</span> Positive - Generally optimistic market view</li>
            <li><span className="text-yellow-500 font-medium">45-59:</span> Neutral - Mixed or balanced sentiment</li>
            <li><span className="text-red-400 font-medium">25-44:</span> Negative - Generally bearish sentiment</li>
            <li><span className="text-red-500 font-medium">0-24:</span> Very Negative - Strong bearish sentiment</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
