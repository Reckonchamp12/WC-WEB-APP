"use client";

import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Brain, LineChart, TrendingUp, BarChart2, CircleDollarSign } from "lucide-react";

// Mock data for feature importance (SHAP values in real application)
const generateFeatureImportance = () => {
  return [
    { feature: "Price Momentum (7d)", value: 0.32, direction: "positive" },
    { feature: "RSI (14)", value: 0.28, direction: "negative" },
    { feature: "Volume Surge", value: 0.24, direction: "positive" },
    { feature: "Moving Avg (50d)", value: 0.21, direction: "positive" },
    { feature: "MACD", value: 0.18, direction: "positive" },
    { feature: "Sector Performance", value: 0.16, direction: "positive" },
    { feature: "Twitter Sentiment", value: 0.14, direction: "negative" },
    { feature: "News Sentiment", value: 0.12, direction: "positive" },
    { feature: "Volatility Index", value: 0.10, direction: "negative" },
    { feature: "Earnings Surprise", value: 0.09, direction: "positive" },
  ].sort((a, b) => Math.abs(b.value) - Math.abs(a.value));
};

// Mock data for sentiment factors
const sentimentFactors = [
  { id: 1, source: "Twitter", score: 72, count: 843, direction: "positive" },
  { id: 2, source: "Reddit", score: 65, count: 221, direction: "positive" },
  { id: 3, source: "News Articles", score: 58, count: 37, direction: "neutral" },
  { id: 4, source: "Financial Blogs", score: 81, count: 16, direction: "positive" },
];

// Mock data for technical indicators
const technicalIndicators = [
  { id: 1, indicator: "RSI (14)", value: "65.3", interpretation: "Neutral (nearing overbought)" },
  { id: 2, indicator: "MACD", value: "2.31", interpretation: "Bullish (above signal line)" },
  { id: 3, indicator: "Moving Average (50d)", value: "$142.76", interpretation: "Bullish (price above MA)" },
  { id: 4, indicator: "Bollinger Bands", value: "Upper", interpretation: "Potential resistance ahead" },
  { id: 5, indicator: "Volume", value: "32.5M", interpretation: "Above average (bullish confirmation)" },
];

interface ModelExplainerProps {
  symbol: string;
  name: string;
  predictionTimeframe?: string;
  confidence?: number;
}

export function ModelExplainer({
  symbol,
  name,
  predictionTimeframe = "5-day",
  confidence = 84
}: ModelExplainerProps) {
  const featureImportance = generateFeatureImportance();

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-2xl flex items-center gap-2">
              <Brain className="h-6 w-6 text-primary" />
              Model Explainability
            </CardTitle>
            <CardDescription>Understanding the {predictionTimeframe} prediction for {symbol}</CardDescription>
          </div>
          <div className="flex items-center bg-primary/10 px-3 py-1 rounded-full">
            <span className="text-sm font-medium text-primary">Confidence: {confidence}%</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="features" className="space-y-4">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="features" className="gap-1">
              <BarChart2 className="h-4 w-4" />
              Feature Importance
            </TabsTrigger>
            <TabsTrigger value="technical" className="gap-1">
              <LineChart className="h-4 w-4" />
              Technical Factors
            </TabsTrigger>
            <TabsTrigger value="sentiment" className="gap-1">
              <TrendingUp className="h-4 w-4" />
              Sentiment Analysis
            </TabsTrigger>
          </TabsList>

          {/* Feature Importance Tab */}
          <TabsContent value="features" className="space-y-4">
            <p className="text-sm text-muted-foreground">
              The chart below shows which factors had the most influence on our {predictionTimeframe} prediction for {symbol}.
              Longer bars indicate stronger influence, while colors show positive (green) or negative (red) impact on the forecast.
            </p>

            <div className="h-[320px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={featureImportance}
                  layout="vertical"
                  margin={{ top: 10, right: 10, left: 120, bottom: 10 }}
                >
                  <XAxis type="number" domain={[0, 'dataMax']} />
                  <YAxis type="category" dataKey="feature" tick={{ fontSize: 12 }} width={120} />
                  <Tooltip
                    formatter={(value: number) => [`${(value * 100).toFixed(1)}% influence`, ""]}
                    contentStyle={{
                      backgroundColor: 'var(--background)',
                      borderColor: 'var(--border)',
                      borderRadius: '8px'
                    }}
                  />
                  <Bar dataKey="value" barSize={20} radius={[0, 4, 4, 0]}>
                    {featureImportance.map((entry) => (
                      <Cell
                        key={`cell-${entry.feature}`}
                        fill={entry.direction === "positive" ? "#22c55e" : "#ef4444"}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          {/* Technical Factors Tab */}
          <TabsContent value="technical" className="space-y-4">
            <p className="text-sm text-muted-foreground mb-4">
              Key technical indicators that influenced our prediction for {symbol}.
            </p>

            <div className="space-y-4">
              {technicalIndicators.map((indicator) => (
                <div key={indicator.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">{indicator.indicator}</h4>
                    <div className="px-3 py-1 bg-primary/10 rounded-full">
                      <span className="text-sm font-medium text-primary">{indicator.value}</span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">{indicator.interpretation}</p>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Sentiment Analysis Tab */}
          <TabsContent value="sentiment" className="space-y-4">
            <p className="text-sm text-muted-foreground mb-4">
              Market sentiment across different platforms for {symbol}.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {sentimentFactors.map((factor) => (
                <Card key={factor.id} className="border">
                  <CardHeader className="py-3">
                    <CardTitle className="text-base">{factor.source}</CardTitle>
                  </CardHeader>
                  <CardContent className="py-2">
                    <div className="flex justify-between items-center">
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Sentiment Score</p>
                        <div className="flex items-center gap-2">
                          <span className={`text-2xl font-bold ${
                            factor.direction === "positive" ? "text-green-500" :
                            factor.direction === "negative" ? "text-red-500" :
                            "text-yellow-500"
                          }`}>
                            {factor.score}
                          </span>
                          <span className="text-sm text-muted-foreground">/100</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Based on</p>
                        <p className="text-lg font-medium">{factor.count} mentions</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Button variant="outline" className="w-full">
              View Detailed Sentiment Report
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
