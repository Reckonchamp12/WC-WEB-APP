"use client";

import { useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

// Data would come from an API in a real application
const generateMockData = (days: number, startPrice: number, isUptrend = true) => {
  const data = [];
  let price = startPrice;

  for (let i = 0; i < days; i++) {
    // Random volatility factor
    const volatility = 0.01 + Math.random() * 0.02;
    // Direction bias
    const direction = isUptrend
      ? (Math.random() > 0.3 ? 1 : -1)
      : (Math.random() > 0.7 ? 1 : -1);

    // Calculate price change
    const change = price * volatility * direction;
    price += change;

    // Calculate predicted price (slightly more optimistic)
    const predictedPrice = price * (1 + (Math.random() * 0.03 * (isUptrend ? 1 : -0.5)));

    // Calculate confidence interval (10% of the price)
    const confidenceUpper = predictedPrice * 1.05;
    const confidenceLower = predictedPrice * 0.95;

    const date = new Date();
    date.setDate(date.getDate() - (days - i - 1));

    data.push({
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      actual: i < days - 5 ? price.toFixed(2) : null, // Only show actual price for past data
      predicted: i >= days - 10 ? predictedPrice.toFixed(2) : null, // Show prediction for last 10 days
      confidenceUpper: i >= days - 10 ? confidenceUpper.toFixed(2) : null,
      confidenceLower: i >= days - 10 ? confidenceLower.toFixed(2) : null,
    });
  }

  return data;
};

type TimeframeOption = '1M' | '3M' | '6M' | '1Y' | 'MAX';

interface StockChartProps {
  symbol: string;
  name: string;
  startPrice?: number;
  isUptrend?: boolean;
}

export function StockChart({
  symbol,
  name,
  startPrice = 150,
  isUptrend = true
}: StockChartProps) {
  const [timeframe, setTimeframe] = useState<TimeframeOption>('1M');

  // Get appropriate number of days based on timeframe
  const getDays = () => {
    switch (timeframe) {
      case '1M': return 30;
      case '3M': return 90;
      case '6M': return 180;
      case '1Y': return 365;
      case 'MAX': return 1095; // ~3 years
      default: return 30;
    }
  };

  const data = generateMockData(getDays(), startPrice, isUptrend);

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <CardTitle className="text-2xl">{symbol}</CardTitle>
            <CardDescription>{name}</CardDescription>
          </div>
          <div className="flex items-center space-x-2">
            {(['1M', '3M', '6M', '1Y', 'MAX'] as TimeframeOption[]).map((option) => (
              <Button
                key={option}
                variant={timeframe === option ? "default" : "outline"}
                size="sm"
                onClick={() => setTimeframe(option)}
              >
                {option}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={data}
              margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
            >
              <defs>
                <linearGradient id="actualGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="predictedGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="confidenceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="date" />
              <YAxis domain={['auto', 'auto']} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'var(--background)',
                  borderColor: 'var(--border)',
                  borderRadius: '8px',
                  boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
                }}
                itemStyle={{ color: 'var(--foreground)' }}
                labelStyle={{ color: 'var(--foreground)' }}
              />
              <Legend />

              {/* Confidence Interval Area */}
              <Area
                type="monotone"
                dataKey="confidenceUpper"
                stroke="none"
                fill="url(#confidenceGradient)"
                fillOpacity={1}
                name="Confidence Interval"
              />
              <Area
                type="monotone"
                dataKey="confidenceLower"
                stroke="none"
                fill="var(--background)"
                fillOpacity={1}
                name="Confidence Interval"
                legendType="none"
              />

              {/* Actual Price Line */}
              <Area
                type="monotone"
                dataKey="actual"
                stroke="#0ea5e9"
                strokeWidth={2}
                fill="url(#actualGradient)"
                name="Actual Price"
              />

              {/* Prediction Line */}
              <Area
                type="monotone"
                dataKey="predicted"
                stroke="#6366f1"
                strokeWidth={2}
                strokeDasharray="5 5"
                fill="url(#predictedGradient)"
                name="Predicted Price"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
