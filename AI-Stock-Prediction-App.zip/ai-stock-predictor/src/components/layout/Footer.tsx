import Link from "next/link";
import { CircleDollarSign, Twitter, Facebook, Instagram, Linkedin, Mail, Phone } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t py-8 md:py-12 bg-gradient-to-b from-background to-muted/30">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1 space-y-4">
            <div className="flex items-center gap-2">
              <div className="relative h-8 w-8">
                <div className="absolute inset-0 bg-blue-500 rounded-full blur-sm opacity-70" />
                <div className="relative z-10 flex items-center justify-center h-full w-full bg-gradient-to-br from-blue-500 to-indigo-700 rounded-full">
                  <CircleDollarSign className="h-5 w-5 text-white" />
                </div>
              </div>
              <div>
                <span className="font-bold text-xl text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-600">Walford Capitals</span>
                <span className="text-xs block -mt-1 text-muted-foreground">AI Stock Predictor</span>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              Cutting-edge AI technology to predict market trends, analyze sentiment,
              and optimize your investment portfolio.
            </p>
            <div className="flex space-x-3">
              <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Twitter className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Facebook className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Instagram className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Linkedin className="h-5 w-5" />
              </Link>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="font-medium text-base">Products</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/stocks" className="text-muted-foreground hover:text-primary">
                  Stock Predictions
                </Link>
              </li>
              <li>
                <Link href="/sentiment" className="text-muted-foreground hover:text-primary">
                  Sentiment Analysis
                </Link>
              </li>
              <li>
                <Link href="/portfolio" className="text-muted-foreground hover:text-primary">
                  Portfolio Optimization
                </Link>
              </li>
              <li>
                <Link href="/trading-bot" className="text-muted-foreground hover:text-primary">
                  Trading Bot
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-3">
            <h3 className="font-medium text-base">Company</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-primary">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="text-muted-foreground hover:text-primary">
                  Pricing & Plans
                </Link>
              </li>
              <li>
                <Link href="/careers" className="text-muted-foreground hover:text-primary">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-muted-foreground hover:text-primary">
                  Blog
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-3">
            <h3 className="font-medium text-base">Contact</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">support@walfordcapitals.com</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">+1 (555) 123-4567</span>
              </li>
              <li>
                <Link href="/contact" className="text-primary hover:underline">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-8 pt-6 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
          <p>
            &copy; {new Date().getFullYear()} Walford Capitals. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link
              href="/privacy"
              className="text-sm font-medium text-muted-foreground hover:text-primary"
            >
              Privacy Policy
            </Link>
            <Link
              href="/terms"
              className="text-sm font-medium text-muted-foreground hover:text-primary"
            >
              Terms of Service
            </Link>
            <Link
              href="/legal"
              className="text-sm font-medium text-muted-foreground hover:text-primary"
            >
              Legal
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
