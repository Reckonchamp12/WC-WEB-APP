"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  CircleDollarSign,
  LineChart,
  BarChart3,
  PieChart,
  Newspaper,
  Briefcase,
  Sun,
  Moon,
  Menu,
  X,
  Bot,
  UserCircle2,
  LogIn
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useTheme } from "next-themes";

const navLinks = [
  { name: "Dashboard", path: "/dashboard", icon: <LineChart className="w-5 h-5 mr-2" /> },
  { name: "Stocks", path: "/stocks", icon: <CircleDollarSign className="w-5 h-5 mr-2" /> },
  { name: "Sentiment", path: "/sentiment", icon: <BarChart3 className="w-5 h-5 mr-2" /> },
  { name: "Portfolio", path: "/portfolio", icon: <Briefcase className="w-5 h-5 mr-2" /> },
  { name: "Trading Bot", path: "/trading-bot", icon: <Bot className="w-5 h-5 mr-2" /> },
  { name: "News", path: "/news", icon: <Newspaper className="w-5 h-5 mr-2" /> },
];

export function Navbar() {
  const pathname = usePathname();
  const { theme, setTheme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="border-b sticky top-0 z-50 bg-background backdrop-blur-md bg-opacity-80 shadow-sm">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center">
          <Link href="/" className="flex items-center mr-6">
            <div className="relative h-8 w-8 mr-2">
              <div className="absolute inset-0 bg-blue-500 rounded-full blur-sm opacity-70"></div>
              <div className="relative z-10 flex items-center justify-center h-full w-full bg-gradient-to-br from-blue-500 to-indigo-700 rounded-full">
                <CircleDollarSign className="h-5 w-5 text-white" />
              </div>
            </div>
            <div>
              <span className="font-bold text-xl text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-600">Walford Capitals</span>
              <span className="text-xs block -mt-1 text-muted-foreground">AI Stock Predictor</span>
            </div>
          </Link>
          <div className="hidden md:flex items-center space-x-1">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                href={link.path}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors
                  ${pathname === link.path
                    ? "bg-primary/10 text-primary shadow-sm"
                    : "text-muted-foreground hover:bg-muted hover:text-primary"
                  }`}
              >
                {link.icon}
                {link.name}
              </Link>
            ))}
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            className="hidden sm:flex items-center gap-1"
            asChild
          >
            <Link href="/auth">
              <LogIn className="h-4 w-4 mr-1" />
              Sign In
            </Link>
          </Button>
          <Button
            variant="default"
            size="sm"
            className="hidden sm:flex items-center gap-1"
            asChild
          >
            <Link href="/auth?signup=true">
              <UserCircle2 className="h-4 w-4 mr-1" />
              Sign Up
            </Link>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            aria-label="Toggle theme"
          >
            {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[280px] sm:w-[350px]">
              <div className="flex items-center mb-6">
                <div className="relative h-8 w-8 mr-2">
                  <div className="absolute inset-0 bg-blue-500 rounded-full blur-sm opacity-70"></div>
                  <div className="relative z-10 flex items-center justify-center h-full w-full bg-gradient-to-br from-blue-500 to-indigo-700 rounded-full">
                    <CircleDollarSign className="h-5 w-5 text-white" />
                  </div>
                </div>
                <div>
                  <span className="font-bold text-xl text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-600">Walford Capitals</span>
                  <span className="text-xs block -mt-1 text-muted-foreground">AI Stock Predictor</span>
                </div>
              </div>

              <div className="flex flex-col space-y-4 mt-4">
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    href={link.path}
                    onClick={() => setIsOpen(false)}
                    className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors
                      ${pathname === link.path
                        ? "bg-primary/10 text-primary"
                        : "text-muted-foreground hover:bg-muted hover:text-primary"
                      }`}
                  >
                    {link.icon}
                    {link.name}
                  </Link>
                ))}

                <div className="border-t pt-4 mt-4">
                  <div className="flex flex-col space-y-2">
                    <Button variant="outline" size="sm" className="justify-start" asChild>
                      <Link href="/auth" onClick={() => setIsOpen(false)}>
                        <LogIn className="h-4 w-4 mr-2" />
                        Sign In
                      </Link>
                    </Button>
                    <Button size="sm" className="justify-start" asChild>
                      <Link href="/auth?signup=true" onClick={() => setIsOpen(false)}>
                        <UserCircle2 className="h-4 w-4 mr-2" />
                        Sign Up
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
